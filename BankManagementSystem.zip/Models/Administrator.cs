﻿namespace BankManagementSystem.Models
{
    public class Administrator : User
    {

    }
}
