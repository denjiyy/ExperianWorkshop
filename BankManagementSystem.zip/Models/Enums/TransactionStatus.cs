﻿namespace BankManagementSystem.Models.Enums
{
    public enum TransactionStatus
    {
        Pending,
        Completed,
        Failed
    }
}
