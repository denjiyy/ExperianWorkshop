﻿namespace BankManagementSystem.Models.Enums
{
    public enum Status
    {
        Closed,
        Active
    }
}
