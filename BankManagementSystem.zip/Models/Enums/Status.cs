﻿namespace BankManagementSystem.Models.Enums
{
    public enum Status
    {
        Active,
        Closed
    }
}
