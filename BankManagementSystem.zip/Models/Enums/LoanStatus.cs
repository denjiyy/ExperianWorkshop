﻿namespace BankManagementSystem.Models.Enums
{
    public enum LoanStatus
    {
        Active,
        PaidOff
    }
}
