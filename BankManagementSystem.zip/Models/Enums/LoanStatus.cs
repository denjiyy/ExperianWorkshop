﻿namespace BankManagementSystem.Models.Enums
{
    public enum LoanStatus
    {
        Active,
        Pending,
        PaidOff
    }
}
