﻿namespace BankManagementSystem.Models.Enums
{
    public enum CardType
    {
        Debit,
        Credit
    }
}
