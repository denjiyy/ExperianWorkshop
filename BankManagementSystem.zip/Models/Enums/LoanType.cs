﻿namespace BankManagementSystem.Models.Enums
{
    public enum LoanType
    {
        Personal,
        Construction,
        Auto,
        Student,
        Agricultural,
        Renovation,
        Mortgage,
        SmallBusiness
    }
}
