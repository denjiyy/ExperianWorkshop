﻿namespace BankManagementSystem.Models.Enums
{
    public enum LoanType
    {
        Personal,
        Mortgage,
        Student
    }
}
