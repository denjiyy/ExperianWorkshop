﻿namespace BankManagementSystem.Models.Enums
{
    public enum AccountType
    {
        Savings,
        Current,
        StudentChecking,
        Basic
    }
}
