﻿namespace BankManagementSystem.Models.Enums
{
    public enum TransactionType
    {
        Deposit,
        Withdrawal,
        FinancialTransaction
    }
}
