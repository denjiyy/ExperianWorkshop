﻿namespace BankManagementSystem.Models.Enums
{
    public enum TransactionType
    {
        Payment,
        Deposit,
        Withdrawal,
        FinancialTransaction
    }
}
