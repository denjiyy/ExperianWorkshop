﻿namespace BankManagementSystem.Models.Enums
{
    public enum CurrencyType
    {
        Bgn,
        Eur,
        Usd
    }
}
