﻿namespace BankManagementSystem.Models.Enums
{
    public enum CurrencyType
    {
        Lev,
        Euro,
        Dollar
    }
}
