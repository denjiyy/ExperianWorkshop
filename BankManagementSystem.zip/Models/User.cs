﻿using BankManagementSystem.Models.Enums;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace BankManagementSystem.Models
{
    [Index("Email", IsUnique = true)]
    [Index("Username", IsUnique = true)]
    public class User
    {
        public User()
        {
            Accounts = new HashSet<Account>();
            Loans = new HashSet<Loan>();
            CreditScore = 100;
            IsAdministrator = true;
        }

        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(60)]
        public string FullName { get; set; }

        [Required]
        [MaxLength(20)]
        public string Username { get; set; }

        [Required]
        [MaxLength(30)]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        [Required]
        public bool IsAdministrator { get; set; }

        [Required]
        public string PhoneNumber { get; set; }

        [Required]
        [MaxLength(30)]
        public string Address { get; set; }

        private int _creditScore;

        [Required]
        public int CreditScore
        {
            get
            {
                return _creditScore;
            }
            set
            {
                _creditScore = Math.Clamp(value, 0, 100);
            }
        }

        [Required]
        public Status Status { get; set; }

        [Required]
        public DateOnly DateOfBirth { get; set; }

        public ICollection<Account> Accounts { get; set; }

        public ICollection<Loan> Loans { get; set; }

        public void UpdateCreditScore(int delta)
        {
            CreditScore = Math.Clamp(CreditScore + delta, 0, 100);
        }
    }
}
