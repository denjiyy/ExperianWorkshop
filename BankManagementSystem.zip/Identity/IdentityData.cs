﻿namespace BankManagementSystem.Identity
{
    public class IdentityData
    {
        public const string AdminUserPolicyName = "Admin";
    }
}
