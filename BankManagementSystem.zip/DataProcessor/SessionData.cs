﻿namespace BankManagementSystem.DataProcessor
{
    public class SessionData
    {
        public string UserId { get; set; }
    }
}
