﻿public class UpdateUserDto
{
    public string Email { get; set; }
    public string Username { get; set; }
    public string NewPassword { get; set; }
}