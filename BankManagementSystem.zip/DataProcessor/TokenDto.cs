﻿namespace BankManagementSystem.DataProcessor
{
    public class TokenDto
    {
        public string RefreshToken { get; set; }
    }
}
